const products = [
  {id:1,name:"Glow Serum",category:"Skincare",price:18500,oldPrice:null,rating:5,tag:"Favorito",image:"https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=700&q=80"},
  {id:2,name:"Hydra Cream",category:"Skincare",price:15000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=700&q=80"},
  {id:3,name:"Rose Toner",category:"Skincare",price:12500,oldPrice:null,rating:4,tag:"",image:"https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?auto=format&fit=crop&w=700&q=80"},
  {id:4,name:"Pure Cleanser",category:"Skincare",price:13000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=700&q=80"},
  {id:5,name:"Luna Mist",category:"Perfumes",price:22000,oldPrice:26000,rating:5,tag:"-15%",image:"https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=700&q=80"},
  {id:6,name:"Vanilla Dream",category:"Perfumes",price:25000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=700&q=80"},
  {id:7,name:"Soft Bloom",category:"Perfumes",price:21500,oldPrice:null,rating:4,tag:"",image:"https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=700&q=80"},
  {id:8,name:"Body Butter",category:"Body Care",price:16000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=700&q=80"},
  {id:9,name:"Sugar Scrub",category:"Body Care",price:11500,oldPrice:14000,rating:4,tag:"Oferta",image:"https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=700&q=80"},
  {id:10,name:"Velvet Lotion",category:"Body Care",price:14000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?auto=format&fit=crop&w=700&q=80"},
  {id:11,name:"Nude Gloss",category:"Maquillaje",price:9000,oldPrice:null,rating:4,tag:"",image:"https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=700&q=80"},
  {id:12,name:"Blush Touch",category:"Maquillaje",price:12000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=700&q=80"},
  {id:13,name:"Glow Set",category:"Sets y Regalos",price:30000,oldPrice:35000,rating:5,tag:"-14%",image:"https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=700&q=80"},
  {id:14,name:"Self Care Box",category:"Sets y Regalos",price:35000,oldPrice:null,rating:5,tag:"",image:"https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=700&q=80"},
  {id:15,name:"Pink Routine",category:"Sets y Regalos",price:28000,oldPrice:null,rating:4,tag:"",image:"https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=700&q=80"}
];

const $ = (selector) => document.querySelector(selector);
const money = value => new Intl.NumberFormat("es-AR",{style:"currency",currency:"ARS",maximumFractionDigits:0}).format(value);
let cart = JSON.parse(localStorage.getItem("lune-cart") || "[]");
let favorites = JSON.parse(localStorage.getItem("lune-favorites") || "[]");
let showFavorites = false;

function saveData(){
  localStorage.setItem("lune-cart",JSON.stringify(cart));
  localStorage.setItem("lune-favorites",JSON.stringify(favorites));
}
function toast(message){
  const box=$("#toast"); box.textContent=message; box.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>box.classList.remove("show"),2300);
}
function renderProducts(){
  const query=$("#searchInput").value.trim().toLowerCase();
  const category=$("#categoryFilter").value;
  const sort=$("#sortFilter").value;
  let list=products.filter(p=>(p.name.toLowerCase().includes(query)||p.category.toLowerCase().includes(query))&&(category==="Todas"||p.category===category));
  if(showFavorites) list=list.filter(p=>favorites.includes(p.id));
  if(sort==="low") list.sort((a,b)=>a.price-b.price);
  if(sort==="high") list.sort((a,b)=>b.price-a.price);
  if(sort==="name") list.sort((a,b)=>a.name.localeCompare(b.name));
  $("#resultCount").textContent=`${list.length} producto${list.length===1?"":"s"} ${showFavorites?"en favoritos": "disponibles"}`;
  $("#emptyProducts").classList.toggle("hidden",list.length!==0);
  $("#productGrid").innerHTML=list.map(p=>`
    <article class="product-card">
      <div class="product-image-wrap">
        <img class="product-image" src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=700&q=80'">
        ${p.tag?`<span class="product-tag">${p.tag}</span>`:""}
        <button class="favorite-button ${favorites.includes(p.id)?"active":""}" data-favorite="${p.id}" aria-label="Agregar ${p.name} a favoritos">${favorites.includes(p.id)?"♥":"♡"}</button>
      </div>
      <div class="product-info">
        <span class="product-category">${p.category}</span><h3>${p.name}</h3>
        <div class="rating">${"★".repeat(p.rating)}${"☆".repeat(5-p.rating)}</div>
        <div class="price-row"><span class="price">${money(p.price)}</span>${p.oldPrice?`<span class="old-price">${money(p.oldPrice)}</span>`:""}</div>
        <button class="add-button" data-add="${p.id}">AGREGAR A LA BOLSA +</button>
      </div>
    </article>`).join("");
}
function addToCart(id){
  const item=cart.find(p=>p.id===id);
  if(item)item.quantity++; else cart.push({id,quantity:1});
  saveData();renderCart();toast("Producto agregado a tu bolsa ✦");
}
function changeQuantity(id,amount){
  const item=cart.find(p=>p.id===id); if(!item)return;
  item.quantity+=amount;
  if(item.quantity<=0)cart=cart.filter(p=>p.id!==id);
  saveData();renderCart();
}
function removeFromCart(id){cart=cart.filter(p=>p.id!==id);saveData();renderCart();toast("Producto eliminado");}
function renderCart(){
  const count=cart.reduce((sum,item)=>sum+item.quantity,0);
  const total=cart.reduce((sum,item)=>sum+products.find(p=>p.id===item.id).price*item.quantity,0);
  $("#cartCount").textContent=count;$("#panelCount").textContent=`(${count})`;$("#cartTotal").textContent=money(total);
  if(!cart.length){$("#cartItems").innerHTML='<p class="cart-empty">Tu bolsa está vacía.<br>¡Descubrí tus favoritos!</p>';return;}
  $("#cartItems").innerHTML=cart.map(item=>{
    const p=products.find(product=>product.id===item.id);
    return `<div class="cart-item"><img src="${p.image}" alt="${p.name}"><div><h4>${p.name}</h4><small>${money(p.price)}</small><div class="quantity"><button data-change="${p.id}" data-amount="-1" aria-label="Disminuir">−</button><span>${item.quantity}</span><button data-change="${p.id}" data-amount="1" aria-label="Aumentar">+</button></div></div><button class="remove-item" data-remove="${p.id}">Quitar</button></div>`;
  }).join("");
}
function openCart(){ $("#cartPanel").classList.add("open");$("#overlay").classList.add("show");$("#cartPanel").setAttribute("aria-hidden","false"); }
function closeCart(){ $("#cartPanel").classList.remove("open");$("#overlay").classList.remove("show");$("#cartPanel").setAttribute("aria-hidden","true"); }

$("#productGrid").addEventListener("click",e=>{
  const add=e.target.closest("[data-add]"),fav=e.target.closest("[data-favorite]");
  if(add)addToCart(Number(add.dataset.add));
  if(fav){const id=Number(fav.dataset.favorite);favorites.includes(id)?favorites=favorites.filter(x=>x!==id):favorites.push(id);saveData();renderProducts();toast(favorites.includes(id)?"Agregado a favoritos ♥":"Quitado de favoritos");}
});
$("#cartItems").addEventListener("click",e=>{
  const change=e.target.closest("[data-change]"),remove=e.target.closest("[data-remove]");
  if(change)changeQuantity(Number(change.dataset.change),Number(change.dataset.amount));
  if(remove)removeFromCart(Number(remove.dataset.remove));
});
$("#searchInput").addEventListener("input",renderProducts);
$("#categoryFilter").addEventListener("change",renderProducts);
$("#sortFilter").addEventListener("change",renderProducts);
document.querySelectorAll(".category-card").forEach(button=>button.addEventListener("click",()=>{
  $("#categoryFilter").value=button.dataset.category;showFavorites=false;renderProducts();$("#productos").scrollIntoView({behavior:"smooth"});
}));
$("#favoritesView").addEventListener("click",()=>{
  showFavorites=!showFavorites;$("#categoryFilter").value="Todas";$("#searchInput").value="";renderProducts();
  $("#productos").scrollIntoView({behavior:"smooth"});toast(showFavorites?"Mostrando tus favoritos":"Mostrando todos los productos");
});
$("#openCart").addEventListener("click",openCart);
$("#closeCart").addEventListener("click",closeCart);
$("#overlay").addEventListener("click",closeCart);
$("#checkoutButton").addEventListener("click",()=>{
  if(!cart.length){toast("Tu bolsa está vacía");return;}
  toast("¡Gracias! Esta es una compra de demostración.");
});
$("#themeToggle").addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  const dark=document.body.classList.contains("dark");
  localStorage.setItem("lune-dark",dark?"true":"false");$("#themeToggle").textContent=dark?"☀":"☾";
});
if(localStorage.getItem("lune-dark")==="true"){document.body.classList.add("dark");$("#themeToggle").textContent="☀";}
$("#newsletterForm").addEventListener("submit",e=>{
  e.preventDefault();const email=$("#newsletterEmail").value.trim();
  if(!email)return;$("#newsletterMessage").textContent="¡Gracias por suscribirte! Pronto tendrás novedades de LUNÉ. ✦";
  $("#newsletterForm").reset();
});
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("show"));
document.querySelectorAll("#mainNav a").forEach(link=>link.addEventListener("click",()=>$("#mainNav").classList.remove("show")));

renderProducts();renderCart();
