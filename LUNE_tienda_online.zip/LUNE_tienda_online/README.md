# LUNÉ — Tienda online

**Eslogan:** Tu momento, tu esencia.

LUNÉ es una tienda online ficticia de belleza, skincare, maquillaje, perfumes y cuidado personal. Este proyecto fue creado con fines educativos utilizando HTML, CSS y JavaScript.

## Tecnologías utilizadas
- HTML: estructura y contenido.
- CSS: diseño visual, colores, tipografías y adaptación a celulares.
- JavaScript: catálogo, filtros, buscador, carrito, favoritos y modo oscuro.
- LocalStorage: guarda el carrito, los favoritos y la preferencia de tema en el navegador.
- Google Fonts e imágenes remotas: recursos visuales externos.

## Funcionalidades
- Catálogo de 15 productos con imagen, nombre, categoría, precio y valoración.
- Cinco categorías de productos.
- Buscador por nombre o categoría.
- Filtros por categoría y orden por precio o nombre.
- Carrito: agregar, quitar, cambiar cantidades y calcular el total.
- Favoritos.
- Modo oscuro.
- Productos con descuentos.
- Formulario de newsletter con confirmación visual.
- Diseño responsive para computadora, tablet y celular.

## Cómo ejecutar el proyecto
1. Descargá los archivos del proyecto.
2. Descomprimí la carpeta si descargaste el ZIP.
3. Abrí `index.html` en un navegador.
4. Para editar el proyecto, abrí la carpeta en Visual Studio Code.

No requiere instalación ni servidor para la demostración básica. Se necesita conexión a internet para cargar las tipografías e imágenes externas.

## Cómo publicarlo en GitHub Pages
1. Iniciá sesión en GitHub y creá un repositorio nuevo llamado `lune-tienda-online`.
2. Elegí que sea público y crealo.
3. Dentro del repositorio, seleccioná **Add file → Upload files**.
4. Subí `index.html`, `style.css`, `script.js` y `README.md` (podés arrastrarlos desde la carpeta).
5. Confirmá la carga con **Commit changes**.
6. Entrá en **Settings → Pages**.
7. En **Build and deployment**, elegí **Deploy from a branch**.
8. Seleccioná la rama `main` y la carpeta `/ (root)`, y guardá.
9. Esperá a que GitHub Pages publique la página. El enlace aparecerá en esa misma sección y tendrá un formato parecido a `https://TU-USUARIO.github.io/lune-tienda-online/`.

## Uso de inteligencia artificial
Se utilizó inteligencia artificial como herramienta de apoyo para proponer la identidad visual, organizar las secciones, generar una primera versión del código HTML, CSS y JavaScript, y explicar las funcionalidades. El código debe ser revisado y comprendido antes de su entrega.

## Aclaraciones
- Los productos y precios son ficticios.
- El botón de finalizar compra muestra una confirmación de demostración: no procesa pagos reales.
- El formulario de newsletter muestra una confirmación local: no envía correos a una base de datos.
- Los enlaces de redes sociales y contacto son ejemplos.
